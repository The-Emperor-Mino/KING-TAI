# Zero World Cultivation RPG Discord Bot

## Description
A fully functional classic manhua cultivation Discord bot. Supports role customization, level pathways, fighting styles, life-vocations, and automatic commands!

## Installation
1. Extract this ZIP file.
2. Run `npm install` to download all requirements.
3. Configure your token in the `.env` file.
4. Run `npm start` or `node bot.js` to run!

Have fun cultivating path to immortality!
