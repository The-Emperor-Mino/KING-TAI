// =========================================================
// ZERO WORLD DISCORD RPG BOT - CORE SOURCE CODE (bot.js)
// =========================================================
// Developed & configured automatically for Discord.js v14
// Supports multiple classes, life jobs, and unique background rates.

require('dotenv').config();
const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

// Configure system thresholds
const LEVEL_STAGES = [
  "تقوية الجسد (Body Refining)",
  "التأسيس الأول (Qi Condensation)",
  "فتح المريدان (Meridian Opening)",
  "دمج التشي (Qi Integration)",
  "النواة الذهبية (Golden Core)",
  "الروح الناشئة (Nascent Soul)"
];

client.once('ready', () => {
  console.log('🤖 Zero World Cultivation RPG Bot is live!');
});

client.on('messageCreate', async message => {
  if (message.author.bot) return;

  if (message.content.toLowerCase() === '!cultivate') {
    message.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle("✨ ممارسة واستنشاق التشي الروحي")
          .setDescription("تبدأ بالتركيز وتوجيه هالات الكون نحو قنوات الميريديان الخاصة بك لتسريع صعود السلف...")
          .setColor("#a855f7")
      ]
    });
  }
});

client.login(process.env.DISCORD_TOKEN);